<?php
$con=new mysqli('localhost','root','','elearning');
if(!$con){
    die(mysqli_error($con));
}


?>
