<h1>E-Learning<h1></h1>

<h2>SNAPSHOTS</h2>

<h3>Login Page</h3>

![Screenshot 2024-02-19 132650](https://github.com/naveeenkm/login/assets/136746420/e1c6b25a-8a3d-4d0a-9c18-49a1f2fbedf8)




<h3>Registration Page</h3>

![Screenshot 2024-02-19 132716](https://github.com/naveeenkm/login/assets/136746420/2da98083-d118-4cb8-b746-9499a28b0bc5)





#Home Page
![Screenshot 2024-02-19 133604](https://github.com/naveeenkm/login/assets/136746420/cbf7af85-5da5-4b7c-98f5-98f6fb82dd17)





#Faculty Registration
![Screenshot 2024-02-19 143642](https://github.com/naveeenkm/login/assets/136746420/20e85217-a496-4159-be68-73fd351e7b8a)




#Student Registration
![Screenshot 2024-02-19 144923](https://github.com/naveeenkm/login/assets/136746420/052e0804-8a79-4386-a51c-a77c5f7c7c59)



![Screenshot 2024-02-19 150839](https://github.com/naveeenkm/login/assets/136746420/92e8d77e-1814-449b-b94f-cea6b31a9787)


![Screenshot 2024-02-19 151304](https://github.com/naveeenkm/login/assets/136746420/850e677d-3a5b-47a4-99a4-56615bcdd86d)

![Screenshot 2024-02-19 152631](https://github.com/naveeenkm/login/assets/136746420/145acdfd-ef48-4804-8a69-98182ae573df)

![Screenshot 2024-02-19 153012](https://github.com/naveeenkm/login/assets/136746420/79f295aa-aa65-4318-bb0f-40f4de8e0d86)




